@extends('templates.adminTemplate')
@section('contenido')
@stop